exports.handler = async (event) => {
    console.log("User migration Lambda invoked");
    return event;
};