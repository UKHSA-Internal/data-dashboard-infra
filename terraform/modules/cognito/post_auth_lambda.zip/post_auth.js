exports.handler = async (event) => {
    console.log("Post-auth Lambda invoked");
    return event;
};