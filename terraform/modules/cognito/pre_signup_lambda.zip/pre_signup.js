exports.handler = async (event) => {
    console.log("Pre-signup Lambda invoked");
    return event;
};